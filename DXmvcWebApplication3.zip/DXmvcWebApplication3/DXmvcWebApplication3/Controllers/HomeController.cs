using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DXmvcWebApplication3.Models;
using DevExpress.XtraPrinting;
using DevExpress.Utils;

using DevExpress.Web.Internal;
using DevExpress.Web.Mvc;
using DevExpress.Web;
using System.IO;
using System.Data.Entity.Validation;
using System.Web.UI;

namespace DXmvcWebApplication3.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            // DXCOMMENT: Pass a data model for GridView
            
            return View(NorthwindDataProvider.GetCustomers());    
        }
        
        public ActionResult GridViewPartialView() 
        {
            // DXCOMMENT: Pass a data model for GridView in the PartialView method's second parameter
            return PartialView("GridViewPartialView", NorthwindDataProvider.GetCustomers());
        }

        public ActionResult ImageUpload()
        {
            UploadControlExtension.GetUploadedFiles("uploadControl", UploadControlHelper.UploadControlValidationSettings, UploadControlHelper.uploadControl_FileUploadComplete);
            return null;
        }
    
    }

    public class UploadControlHelper
    {
        public static readonly DevExpress.Web.UploadControlValidationSettings UploadControlValidationSettings = new DevExpress.Web.UploadControlValidationSettings
        {
            AllowedFileExtensions = new string[] { ".xls", ".xlsx", ".docx", ".pdf" },
            MaxFileSize = 4000000
        };

        public static void uploadControl_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            if (e.UploadedFile.IsValid)
            {
                string resultFilePath = "~/Content/UploadFiles/" + string.Format("Project{0}{1}", "_200_", Path.GetExtension(e.UploadedFile.FileName));
                e.UploadedFile.SaveAs(HttpContext.Current.Request.MapPath(resultFilePath));
                IUrlResolutionService urlResolver = sender as IUrlResolutionService;
                if (urlResolver != null)
                    e.CallbackData = urlResolver.ResolveClientUrl(resultFilePath) + "?refresh=" + Guid.NewGuid().ToString();
            }
        }
    }
}